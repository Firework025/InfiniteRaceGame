﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Taskbar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrayNotify;

namespace InfiniteRaceGame
{
    public partial class Form1 : Form
    {
        private bool lose = false;
        private int countCoins = 0;
        private int backgroundSpeed = 8;
        private int traficSpeed = 6;
        private int traficBackSpeed = 12;

        public Form1()
        {
            InitializeComponent();
            loseLabel.Visible = false;
            retryButton.Visible = false;
            easyButton.Visible = false;
            normalButton.Visible = false;
            hardButton.Visible = false;
            KeyPreview = true;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            EntityMove(background, backgroundSpeed, 0, 0);
            EntityMove(backgroundTop, backgroundSpeed, -761, 0);
            EntityMove(backgroundBottom, backgroundSpeed, -188, 0);

            Random random = new Random();

            EntityMove(trafic1, traficSpeed, playersCar.Top - 1000, random.Next(410,680));
            EntityMove(trafic2, traficSpeed, playersCar.Top - 1000, random.Next(410, 680));

            EntityMove(traficBack2, traficBackSpeed, playersCar.Top - 1000, random.Next(10, 280));
            EntityMove(traficBack1, traficBackSpeed, playersCar.Top - 1000, random.Next(10, 280));

            EntityMove(coin1, backgroundSpeed, playersCar.Top - 1000, random.Next(10, 280));
            EntityMove(coin2, backgroundSpeed, playersCar.Top - 1000, random.Next(410, 680));


            if (playersCar.Bounds.IntersectsWith(coin1.Bounds))
            {
                coin1.Left = random.Next(10, 280);
                coin1.Top = playersCar.Top - 1000;
                countCoins++;  
                coinsLabel.Text = "Монеты: " + countCoins.ToString();
            }

            if (playersCar.Bounds.IntersectsWith(coin2.Bounds))
            {
                coin2.Left = random.Next(410, 680);
                coin2.Top = playersCar.Top - 1000;
                countCoins++;
                coinsLabel.Text = "Монеты: " + countCoins.ToString();
            }
            
            if (playersCar.Bounds.IntersectsWith(trafic1.Bounds) || playersCar.Bounds.IntersectsWith(trafic2.Bounds) 
            || playersCar.Bounds.IntersectsWith(traficBack1.Bounds)
            || playersCar.Bounds.IntersectsWith(traficBack2.Bounds))
            {
                timer.Stop();
                loseLabel.Visible = true;
                retryButton.Visible = true;
                easyButton.Visible = true;
                normalButton.Visible = true;
                hardButton.Visible = true;
                lose = true;
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (lose) return;

            var carSpeed = 15;
            if ((e.KeyCode == Keys.A || e.KeyCode == Keys.Left) && playersCar.Left > 10)
                playersCar.Left -= carSpeed; 
            else if ((e.KeyCode == Keys.D || e.KeyCode == Keys.Right) && playersCar.Right < 774)
                playersCar.Left += carSpeed;
        }

        private void EntityMove(PictureBox entity, int speed, int startPositionY, int startPositionX)
        {
            if (entity.Top > 761)
            {
                entity.Top = startPositionY;
                entity.Left = startPositionX;
            }
            entity.Top += speed;
        }
  
        private void retryButton_Click(object sender, EventArgs e)
        {
            loseLabel.Visible = false;
            retryButton.Visible = false;
            easyButton.Visible = false;
            normalButton.Visible = false;
            hardButton.Visible = false;
            timer.Start();
            lose = false;
            countCoins = 0;
            coinsLabel.Text = "Монеты: 0";

            Random random = new Random();
            EntityRetry(trafic1, -200, random.Next(410, 680));
            EntityRetry(trafic2, -500, random.Next(410, 680));
            EntityRetry(coin2, -800, random.Next(410, 680));
            EntityRetry(coin1, -200, random.Next(10, 280));
            EntityRetry(traficBack2, -500, random.Next(10, 280));
            EntityRetry(traficBack1, -800, random.Next(10, 280));

            playersCar.Left = 550;      
        }

        private void EntityRetry(PictureBox entity, int startPositionX, int startPositionY)
        {
            var traficStartPos = -300;
            entity.Top = traficStartPos + startPositionX;
            entity.Left = startPositionY;
        }

        private void normalButton_Click(object sender, EventArgs e)
        {
            backgroundSpeed = 8;
            traficSpeed = 6;
            traficBackSpeed = 12;
        }

        private void easyButton_Click(object sender, EventArgs e)
        {
            backgroundSpeed = 4;
            traficSpeed = 3;
            traficBackSpeed = 6;
        }

        private void hardButton_Click(object sender, EventArgs e)
        {
            backgroundSpeed = 12;
            traficSpeed = 9;
            traficBackSpeed = 18;
        }
    }
}
