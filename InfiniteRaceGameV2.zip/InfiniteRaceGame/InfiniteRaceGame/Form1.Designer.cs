﻿namespace InfiniteRaceGame
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.background = new System.Windows.Forms.PictureBox();
            this.playersCar = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.backgroundTop = new System.Windows.Forms.PictureBox();
            this.backgroundBottom = new System.Windows.Forms.PictureBox();
            this.trafic1 = new System.Windows.Forms.PictureBox();
            this.trafic2 = new System.Windows.Forms.PictureBox();
            this.trafic3 = new System.Windows.Forms.PictureBox();
            this.traficBack1 = new System.Windows.Forms.PictureBox();
            this.traficBack3 = new System.Windows.Forms.PictureBox();
            this.traficBack2 = new System.Windows.Forms.PictureBox();
            this.loseLabel = new System.Windows.Forms.Label();
            this.retryButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.background)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playersCar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backgroundTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backgroundBottom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafic3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.traficBack1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.traficBack3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.traficBack2)).BeginInit();
            this.SuspendLayout();
            // 
            // background
            // 
            this.background.Image = ((System.Drawing.Image)(resources.GetObject("background.Image")));
            this.background.Location = new System.Drawing.Point(0, 0);
            this.background.Name = "background";
            this.background.Size = new System.Drawing.Size(784, 761);
            this.background.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.background.TabIndex = 0;
            this.background.TabStop = false;
            // 
            // playersCar
            // 
            this.playersCar.BackColor = System.Drawing.Color.Transparent;
            this.playersCar.Image = ((System.Drawing.Image)(resources.GetObject("playersCar.Image")));
            this.playersCar.Location = new System.Drawing.Point(550, 500);
            this.playersCar.Name = "playersCar";
            this.playersCar.Size = new System.Drawing.Size(90, 175);
            this.playersCar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.playersCar.TabIndex = 1;
            this.playersCar.TabStop = false;
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 15;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // backgroundTop
            // 
            this.backgroundTop.Image = ((System.Drawing.Image)(resources.GetObject("backgroundTop.Image")));
            this.backgroundTop.Location = new System.Drawing.Point(0, -761);
            this.backgroundTop.Name = "backgroundTop";
            this.backgroundTop.Size = new System.Drawing.Size(784, 761);
            this.backgroundTop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backgroundTop.TabIndex = 2;
            this.backgroundTop.TabStop = false;
            // 
            // backgroundBottom
            // 
            this.backgroundBottom.Image = ((System.Drawing.Image)(resources.GetObject("backgroundBottom.Image")));
            this.backgroundBottom.Location = new System.Drawing.Point(0, -188);
            this.backgroundBottom.Name = "backgroundBottom";
            this.backgroundBottom.Size = new System.Drawing.Size(784, 761);
            this.backgroundBottom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backgroundBottom.TabIndex = 3;
            this.backgroundBottom.TabStop = false;
            // 
            // trafic1
            // 
            this.trafic1.BackColor = System.Drawing.Color.Transparent;
            this.trafic1.Image = ((System.Drawing.Image)(resources.GetObject("trafic1.Image")));
            this.trafic1.Location = new System.Drawing.Point(446, -200);
            this.trafic1.Name = "trafic1";
            this.trafic1.Size = new System.Drawing.Size(90, 175);
            this.trafic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.trafic1.TabIndex = 4;
            this.trafic1.TabStop = false;
            // 
            // trafic2
            // 
            this.trafic2.BackColor = System.Drawing.Color.Transparent;
            this.trafic2.Image = ((System.Drawing.Image)(resources.GetObject("trafic2.Image")));
            this.trafic2.Location = new System.Drawing.Point(653, -500);
            this.trafic2.Name = "trafic2";
            this.trafic2.Size = new System.Drawing.Size(90, 175);
            this.trafic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.trafic2.TabIndex = 5;
            this.trafic2.TabStop = false;
            // 
            // trafic3
            // 
            this.trafic3.BackColor = System.Drawing.Color.Transparent;
            this.trafic3.Image = ((System.Drawing.Image)(resources.GetObject("trafic3.Image")));
            this.trafic3.Location = new System.Drawing.Point(446, -800);
            this.trafic3.Name = "trafic3";
            this.trafic3.Size = new System.Drawing.Size(90, 175);
            this.trafic3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.trafic3.TabIndex = 6;
            this.trafic3.TabStop = false;
            // 
            // traficBack1
            // 
            this.traficBack1.BackColor = System.Drawing.Color.Transparent;
            this.traficBack1.Image = ((System.Drawing.Image)(resources.GetObject("traficBack1.Image")));
            this.traficBack1.Location = new System.Drawing.Point(255, -200);
            this.traficBack1.Name = "traficBack1";
            this.traficBack1.Size = new System.Drawing.Size(90, 175);
            this.traficBack1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.traficBack1.TabIndex = 7;
            this.traficBack1.TabStop = false;
            // 
            // traficBack3
            // 
            this.traficBack3.BackColor = System.Drawing.Color.Transparent;
            this.traficBack3.Image = ((System.Drawing.Image)(resources.GetObject("traficBack3.Image")));
            this.traficBack3.Location = new System.Drawing.Point(38, -800);
            this.traficBack3.Name = "traficBack3";
            this.traficBack3.Size = new System.Drawing.Size(90, 175);
            this.traficBack3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.traficBack3.TabIndex = 8;
            this.traficBack3.TabStop = false;
            // 
            // traficBack2
            // 
            this.traficBack2.BackColor = System.Drawing.Color.Transparent;
            this.traficBack2.Image = ((System.Drawing.Image)(resources.GetObject("traficBack2.Image")));
            this.traficBack2.Location = new System.Drawing.Point(38, -500);
            this.traficBack2.Name = "traficBack2";
            this.traficBack2.Size = new System.Drawing.Size(90, 175);
            this.traficBack2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.traficBack2.TabIndex = 9;
            this.traficBack2.TabStop = false;
            // 
            // loseLabel
            // 
            this.loseLabel.AutoSize = true;
            this.loseLabel.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.loseLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.loseLabel.Font = new System.Drawing.Font("Calibri", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.loseLabel.ForeColor = System.Drawing.Color.White;
            this.loseLabel.Location = new System.Drawing.Point(265, 300);
            this.loseLabel.Name = "loseLabel";
            this.loseLabel.Size = new System.Drawing.Size(249, 47);
            this.loseLabel.TabIndex = 10;
            this.loseLabel.Text = "Вы проиграли";
            this.loseLabel.UseWaitCursor = true;
            // 
            // retryButton
            // 
            this.retryButton.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.retryButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.retryButton.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.retryButton.ForeColor = System.Drawing.Color.White;
            this.retryButton.Location = new System.Drawing.Point(332, 361);
            this.retryButton.Name = "retryButton";
            this.retryButton.Size = new System.Drawing.Size(116, 59);
            this.retryButton.TabIndex = 11;
            this.retryButton.Text = "Заново";
            this.retryButton.UseVisualStyleBackColor = false;
            this.retryButton.Click += new System.EventHandler(this.retryButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(784, 761);
            this.Controls.Add(this.retryButton);
            this.Controls.Add(this.loseLabel);
            this.Controls.Add(this.playersCar);
            this.Controls.Add(this.traficBack2);
            this.Controls.Add(this.traficBack3);
            this.Controls.Add(this.traficBack1);
            this.Controls.Add(this.trafic3);
            this.Controls.Add(this.trafic2);
            this.Controls.Add(this.trafic1);
            this.Controls.Add(this.backgroundBottom);
            this.Controls.Add(this.background);
            this.Controls.Add(this.backgroundTop);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.background)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playersCar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backgroundTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backgroundBottom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafic3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.traficBack1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.traficBack3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.traficBack2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox background;
        private System.Windows.Forms.PictureBox playersCar;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.PictureBox backgroundTop;
        private System.Windows.Forms.PictureBox backgroundBottom;
        private System.Windows.Forms.PictureBox trafic1;
        private System.Windows.Forms.PictureBox trafic2;
        private System.Windows.Forms.PictureBox trafic3;
        private System.Windows.Forms.PictureBox traficBack1;
        private System.Windows.Forms.PictureBox traficBack3;
        private System.Windows.Forms.PictureBox traficBack2;
        private System.Windows.Forms.Label loseLabel;
        private System.Windows.Forms.Button retryButton;
    }
}

