﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Taskbar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrayNotify;

namespace InfiniteRaceGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer_Tick(object sender, EventArgs e)
        {
            var backgroundSpeed = 10;
            EntityMove(background, backgroundSpeed, 0, 0);
            EntityMove(backgroundTop, backgroundSpeed, -761, 0);
            EntityMove(backgroundBottom, backgroundSpeed, -188, 0);

            var traficSpeed = 5;
            var traficStartPos = -300;
            Random random = new Random();
            EntityMove(trafic1, traficSpeed, traficStartPos, random.Next(410,680));
            ///EntityMove(trafic2, traficSpeed, traficStartPos, random.Next(410, 680));
            EntityMove(trafic3, traficSpeed, traficStartPos, random.Next(410, 680));

            var traficBackSpeed = 10;
            EntityMove(traficBack1, traficBackSpeed, traficStartPos, random.Next(10, 280));
            ///EntityMove(traficBack2, traficBackSpeed, traficStartPos, random.Next(10, 280));
            EntityMove(traficBack3, traficBackSpeed, traficStartPos, random.Next(10, 280));
            
            if (playersCar.Bounds.IntersectsWith(trafic1.Bounds) || playersCar.Bounds.IntersectsWith(trafic2.Bounds) 
                || playersCar.Bounds.IntersectsWith(trafic3.Bounds) || playersCar.Bounds.IntersectsWith(traficBack1.Bounds)
                || playersCar.Bounds.IntersectsWith(traficBack2.Bounds) || playersCar.Bounds.IntersectsWith(traficBack3.Bounds))
            {
                timer.Stop();
            }

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            var carSpeed = 15;

            if ((e.KeyCode == Keys.A || e.KeyCode == Keys.Left) && playersCar.Left > 10)
                playersCar.Left -= carSpeed; 
            else if ((e.KeyCode == Keys.D || e.KeyCode == Keys.Right) && playersCar.Right < 774)
                playersCar.Left += carSpeed;
        }

        private void EntityMove(PictureBox entity, int speed, int startPositionY, int startPositionX)
        {
            if (entity.Top > 761)
            {
                entity.Top = startPositionY;
                entity.Left = startPositionX;
            }
            entity.Top += speed;
        }
        private void backgroundBottom_Click(object sender, EventArgs e)
        {

        }
    }
}
